<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $user=Auth::user();
    if (Auth::check()) {
        return redirect("/products");
    } else {
        return view('home');
    }
});

Route::get('/products', 'ProductsController@index');

Route::get('/products/{id}/show', 'ProductsController@show');

Route::get('/products/create', 'ProductsController@create');
Route::post('/products', 'ProductsController@store');

Route::get('/products/{id}/edit', 'ProductsController@edit');
Route::put('/products/{id}', 'ProductsController@update');

Route::get('/products/{id}/remove', 'ProductsController@remove');
Route::delete('/products/{id}', 'ProductsController@destroy');

Route::get('/products/{id}/restore', 'ProductsController@restore');
Route::post('/products/{id}/undelete', 'ProductsController@undelete');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/admin','AdministratorController@index');