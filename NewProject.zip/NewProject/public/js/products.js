function returnpage() {
  location.href='/products';
}