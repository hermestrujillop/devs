<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Product;

use App\Http\Requests\CreateProductRequest;

use Illuminate\Support\Facades\Auth;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user=Auth::user();
        if (Auth::check()) {
            $products=Product::withTrashed()->get();
            return view("products.index", compact("products"));
        } else {
            return redirect('/home');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user=Auth::user();
        if (Auth::check()) {
            return view("products.create");
        } else {
            return redirect('/home');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CreateProductRequest $request)
    {
        //$this->validate($request, ['name'=>'required','section'=>'required','date'=>'required','price'=>'required','source_country'=>'required']);
        /*
        $product=new Product;
        $product->name=$request->name;
        $product->section=$request->section;
        $product->date=$request->date;
        $product->price=$request->price;
        $product->source_country=$request->source_country;
        $product->save();
        */
        $user=Auth::user();
        if (Auth::check()) {
            $data=$request->all();
            if ($file=$request->file('image')) {
                $filename=$file->getClientOriginalName();
                $file->move('images', $filename);
                $data['image_path']=$filename;
            }
            Product::create($data);
            return redirect("/products");
        } else {
            return redirect('/home');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user=Auth::user();
        if (Auth::check()) {
            $products=Product::withTrashed()->where('id', $id)->get();
            return view ("products.show", compact("products")); 
        } else {
            return redirect('/home');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user=Auth::user();
        if (Auth::check()) {
            $product=Product::findOrFail($id);
            return view ("products.edit", compact("product")); 
        } else {
            return redirect('/home');
        }
    }

    public function remove($id)
    {
        $user=Auth::user();
        if (Auth::check()) {
            $product=Product::findOrFail($id);
            return view ("products.remove", compact("product"));
        } else {
            return redirect('/home');
        }
    }

    public function restore($id)
    {
        $user=Auth::user();
        if (Auth::check()) {
            $products=Product::withTrashed()->where('id', $id)->get();
            return view ("products.restore", compact("products"));
        } else {
            return redirect('/home');
        }
        //return $product->name;
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CreateProductRequest $request, $id)
    {
        $user=Auth::user();
        if (Auth::check()) {
            $product=Product::findOrFail($id);
            $data=$request->all();
            if ($file=$request->file('image')) {
                $filename=$file->getClientOriginalName();
                $file->move('images', $filename);
                $data['image_path']=$filename;
            }
            $product->update($data);
            return redirect("/products");
        } else {
            return redirect('/home');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user=Auth::user();
        if (Auth::check()) {
            $product=Product::findOrFail($id);
            $product->delete();
            return redirect("/products");
        } else {
            return redirect('/home');
        }
    }
    public function undelete($id)
    {
        $user=Auth::user();
        if (Auth::check()) {
            $product=Product::onlyTrashed()->where('id', $id)->restore();
            return redirect("/products");
        } else {
            return redirect('/home');
        }
    }
}
