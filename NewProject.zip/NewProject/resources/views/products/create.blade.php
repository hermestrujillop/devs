@extends("../layouts.template")

@section("header")
INSERT PRODUCTS
@endsection

@section("container")
 {!! Form::open(['url' => '/products', 'method'=>'post', 'files'=>true]) !!}
  <table>
   <tr>
    <td>
     {!! Form::label('image', 'Image:') !!}
    </td>
    <td>
     {!! Form::file('image') !!}
    </td>
   </tr>
   <tr>
    <td>
     {!! Form::label('name', 'Name:') !!}
    </td>
    <td>
     {!! Form::text('name') !!}
    </td>
   </tr>
   <tr>
    <td>
    {!! Form::label('section', 'Section:') !!}
    </td>
    <td>
     {!! Form::text('section') !!}
    </td>
   </tr>
   <tr>
    <td>
     {!! Form::label('price', 'Price:') !!}
    </td>
    <td>
     {!! Form::text('price') !!}
    </td>
   </tr>
   <tr>
    <td>
     {!! Form::label('date', 'Date:') !!}
    </td>
    <td>
     {!! Form::text('date') !!}
    </td>
   </tr>
   <tr>
    <td>
    {!! Form::label('source_country', 'Source Country:') !!}
    </td>
    <td>
     {!! Form::text('source_country') !!}
    </td>
   </tr>
   <tr>
    <th>
     {!! Form::submit('Send') !!}
    </th>
    <th>
     {!! Form::reset('Reset') !!}
    </th>
   </tr>
  </table>
  {!! Form::close() !!}
  @if (count($errors)>0)
       <ul>
       @foreach($errors->all() as $error)
         <li>{{$error}}</li>
       @endforeach
       </ul>
  @endif
@endsection

@section("footer")
@endsection