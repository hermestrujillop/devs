@extends("../layouts.template")

@section("header")

@section("container")
  <form method="post">
  <input type="text" name="name">
  <input type="submit" name="send" value="send">
  </form>