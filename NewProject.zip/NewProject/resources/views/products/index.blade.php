@extends("../layouts.template")

@section("header")
 PRODUCTS LIST
@endsection

@section("container")

 <table border="1" cellspacing="0" cellpadding="0">
  <tr>
   <th colspan="8"><input type="button" name="new" value="New" onclick="location.href='/products/create'"></th>
  </tr>
  <tr>
   <th>Id</th>
   <th>Name</th>
   <th>Section</th>
   <th>Price</th>
   <th>Date</th>
   <th>Source Country</th>
   <th colspan="2">Action</th>
  </tr>
  @foreach($products as $product)
   <tr>
    <td><a href="/products/{{$product->id}}/show">{{$product->id}}</a></td>
    <td>{{$product->name}}</td>
    <td>{{$product->section}}</td>
    <td>{{$product->price}}</td>
    <td>{{$product->date}}</td>
    <td>{{$product->source_country}}</td>
    @if ($product->deleted_at==null)
    <td><a href="/products/{{$product->id}}/edit">Edit</a></td>
    <td><a href="/products/{{$product->id}}/remove">Delete</a></td>
    @else
    <td></td>
    <td><a href="/products/{{$product->id}}/restore">Undelete</a></td>
    @endif
   </tr>
  @endforeach
 </table>
@endsection

@section("footer")
@endsection