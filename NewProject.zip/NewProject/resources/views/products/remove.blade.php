@extends("../layouts.template")
{!! Html::script('js/products.js') !!}

@section("header")
DELETE PRODUCTS
@endsection

@section("container")
 {!! Form::model($product, ['method'=>'DELETE', 'action'=>['ProductsController@destroy', $product->id]]) !!}
  <table>
   <tr>
    <td>
     {!! Form::label('name', 'Name:') !!}
    </td>
    <td>
     {!! Form::text('name', $product->name) !!}
    </td>
   </tr>
   <tr>
    <td>
    {!! Form::label('section', 'Section:') !!}
    </td>
    <td>
     {!! Form::text('section', $product->section) !!}
    </td>
   </tr>
   <tr>
    <td>
     {!! Form::label('price', 'Price:') !!}
    </td>
    <td>
     {!! Form::text('price', $product->price) !!}
    </td>
   </tr>
   <tr>
    <td>
     {!! Form::label('date', 'Date:') !!}
    </td>
    <td>
     {!! Form::text('date', $product->date) !!}
    </td>
   </tr>
   <tr>
    <td>
    {!! Form::label('source_country', 'Source Country:') !!}
    </td>
    <td>
     {!! Form::text('source_country', $product->source_country) !!}
    </td>
   </tr>
   <tr>
    <th>
     {!! Form::submit('Delete') !!}
    </th>
    <th>
     {!! Form::button('Return', ['onclick'=>'returnpage()']) !!}
    </th>
   </tr>
  </table>
 {!! Form::close() !!}
@endsection

@section("footer")
@endsection