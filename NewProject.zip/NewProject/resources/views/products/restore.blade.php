@extends("../layouts.template")
{!! Html::script('js/products.js') !!}

@section("header")
UNDELETE PRODUCTS
@endsection

@section("container")
 @foreach($products as $product)
 {!! Form::model($product, ['method'=>'POST', 'action'=>['ProductsController@undelete', $product->id]]) !!}
  <table>
   <tr>
    <td>
     {!! Form::label('name', 'Name:') !!}
    </td>
    <td>
     {!! Form::text('name', $product->name) !!}
    </td>
   </tr>
   <tr>
    <td>
    {!! Form::label('section', 'Section:') !!}
    </td>
    <td>
     {!! Form::text('section', $product->section) !!}
    </td>
   </tr>
   <tr>
    <td>
     {!! Form::label('price', 'Price:') !!}
    </td>
    <td>
     {!! Form::text('price', $product->price) !!}
    </td>
   </tr>
   <tr>
    <td>
     {!! Form::label('date', 'Date:') !!}
    </td>
    <td>
     {!! Form::text('date', $product->date) !!}
    </td>
   </tr>
   <tr>
    <td>
    {!! Form::label('source_country', 'Source Country:') !!}
    </td>
    <td>
     {!! Form::text('source_country', $product->source_country) !!}
    </td>
   </tr>
   <tr>
    <th>
     {!! Form::submit('Undelete') !!}
    </th>
    <th>
     {!! Form::button('Return', ['onclick'=>'returnpage()']) !!}
    </th>
   </tr>
  </table>
 </form>
 @endforeach
@endsection

@section("footer")
@endsection