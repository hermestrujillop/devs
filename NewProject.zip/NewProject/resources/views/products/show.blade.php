@extends("../layouts.template")

@section("header")
SHOW PRODUCT
@endsection

@section("container")
 @foreach($products as $product)
  <table>
   <tr>
    <th colspan="2">
     <img src="/images/{{$product->image_path}}" width="50%" />
    </th>
   </tr>
   <tr>
    <td>
     Name:
    </td>
    <td>
     @if ($product->deleted_at!=null)
     <input type="text" name="name"  value="{{$product->name}}" Readonly style="color:red">
     @else
     <input type="text" name="name"  value="{{$product->name}}" Readonly style="color:blue">
     @endif
     <input type="hidden" name="_token" value="{{ csrf_token() }}">
    </td>
   </tr>
   <tr>
    <td>
     Section:
    </td>
    <td>
     <input type="text" name="section" value="{{$product->section}}" Readonly>
    </td>
   </tr>
   <tr>
    <td>
     Price:
    </td>
    <td>
     <input type="text" name="price" value="{{$product->price}}" Readonly>
    </td>
   </tr>
   <tr>
    <td>
     Date:
    </td>
    <td>
     <input type="text" name="date" value="{{$product->date}}" Readonly>
    </td>
   </tr>
   <tr>
    <td>
     Source Country:
    </td>
    <td>
     <input type="text" name="source_country" value="{{$product->source_country}}" Readonly>
    </td>
   </tr>
   <tr>
    <th colspan="2">
     <input type="button" name="return" value="Return" onclick="location.href='/products'">
    </th>
   </tr>
  </table>
  @endforeach
@endsection

@section("footer")
@endsection