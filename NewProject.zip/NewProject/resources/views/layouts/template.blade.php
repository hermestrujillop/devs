<!doctype html>
<html>
 <head>
  <meta charset="utf-8">
  <title>Products</title>
  <style>
   .imgHeader {
       float:right;
       padding-right:50px;
       width:50px;
   }
   .header {
       text-align:center;
       font-size:x-large;
       font-family:Tahoma, Geneva, sans-serif;
       margin-bottom:100px;
       color:#090;
   }
   .loggeduser {
       float:right;
       font-size:0.9em;
       font-family:Tahoma, Geneva, sans-serif;
       margin-bottom:100px;
       color:#0B0B61;
   }
   .container form {
       width:300px;
       margin:0 auto;
   }
   .container table {
       width:500px;
       margin:0 auto;
   }
   .footer {
       position:fixed;
       bottom:0px;
       width:100%;
       font-size:0.7em;
       margin-bottom:15px;
       font-family:Tahoma, Geneva, sans-serif;
       text-align:center;
   }
   .byHTP {
       font-size:1em;
       font-family:Tahoma, Geneva, sans-serif;
       font-weight:bold;
       color:#090;
   }
  </style>
 </head>
 <body>
  <div class="header">
   @yield("header")
   <span class="loggeduser">{{session('user')}} ({{session('role')}}) <img src="/images/My_eye_2019.png" class="imgHeader" onclick="location.href='/home'"/></span>
  </div>
  <div class="container">
   @yield("container")
  </div>
  <div class="footer">
   @yield("footer")
   Laravel Exercises by <span class="byHTP">HermesTrujilloP</span> - All Rights Reserved &copy; <?php echo date("Y");?>
  </div>
 </body>
</html>